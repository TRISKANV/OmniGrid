# OmniGrid — Guía de Integración
## Payload Manager + Ducky Runtime → Runtime OS

---

## 📋 Checklist de integración

### 1. Gradle

Agregar al `build.gradle (app)` lo que está en `GRADLE_DEPENDENCIES.gradle.kts`.

Verificar que el proyecto ya tiene:
- `com.google.dagger.hilt.android` plugin
- `com.google.devtools.ksp` plugin
- BOM de Compose

---

### 2. AndroidManifest.xml

Agregar los bloques de `MANIFEST_ADDITIONS.xml` al manifest existente.

---

### 3. Hilt Application

Asegurarse que la clase Application tiene `@HiltAndroidApp`:

```kotlin
@HiltAndroidApp
class OmniGridApplication : Application()
```

---

### 4. Conectar los bridges del Runtime OS

En `PayloadModule.kt (DI)`, los tres bridges están como **stubs de log**.
Hay que reemplazarlos con los componentes reales de OmniGrid:

```kotlin
// En OmniRuntimeBridgeModule:

@Provides
@Singleton
fun provideOmniRuntimeEventBus(
    coreEventBus: CoreEventBus  // ← tu CoreEventBus existente
): OmniRuntimeEventBus = object : OmniRuntimeEventBus {
    override suspend fun emit(event: OmniRuntimeEvent) {
        coreEventBus.emit(event.toCoreEvent())
    }
}

@Provides
@Singleton
fun provideOmniTelemetryBridge(
    telemetry: RuntimeTelemetryManager  // ← tu TelemetryManager existente
): OmniTelemetryBridge = object : OmniTelemetryBridge {
    override fun record(metric: TelemetryMetric) {
        telemetry.record(metric.key, metric.value, metric.tags)
    }
}

@Provides
@Singleton
fun provideOmniTimelineBridge(
    timeline: OperationalTimeline  // ← tu OperationalTimeline existente
): OmniTimelineBridge = object : OmniTimelineBridge {
    override fun record(moduleId: String, eventType: String, label: String, timestamp: Long) {
        timeline.record(moduleId, eventType, label, timestamp)
    }
}
```

---

### 5. Registrar el módulo en RuntimePluginSystem

```kotlin
// En tu RuntimePluginSystem o donde registres plugins:

@Inject lateinit var payloadModule: PayloadModule

fun initialize() {
    pluginRegistry.register(payloadModule)
    payloadModule.initialize(context)
}
```

---

### 6. Agregar navegación al ModularDashboard

```kotlin
// En tu dashboard principal, agregar tile/entrada al Payload Manager:

PayloadManagerTile(
    onClick = {
        navController.navigate(PayloadRoute.Manager.route)
    }
)

// O embeber el NavGraph completo:
PayloadNavGraph(navController = navController)
```

---

### 7. Transport Layer en producción

Por defecto usa `SimulatedTransportLayer` (seguro para desarrollo).

Para USB HID real, cambiar en `PayloadRuntimeModule`:

```kotlin
@Provides
@Singleton
fun provideTransportLayer(
    @ApplicationContext context: Context
): TransportLayer = UsbHidTransportLayer()
// + pasar UsbManager al constructor
```

---

## 🗂️ Inventario de archivos — todos nuevos

| Archivo | Paquete | Tipo |
|---------|---------|------|
| `PayloadModels.kt` | `domain/model` | Domain models |
| `PayloadRepository.kt` | `domain/repository` | Interface |
| `PayloadUseCases.kt` | `domain/usecase` | 6 use cases |
| `PayloadEntities.kt` | `data/local/entity` | Room entities + mappers |
| `PayloadDaos.kt` | `data/local/dao` | Room DAOs |
| `PayloadDatabase.kt` | `data/local` | Room DB |
| `PayloadRepositoryImpl.kt` | `data/repository` | Impl |
| `DuckyScriptParser.kt` | `runtime/engine` | Parser |
| `DuckyRuntimeEngine.kt` | `runtime/engine` | Engine principal |
| `PayloadRuntimeEvent.kt` | `runtime/events` | Sealed events |
| `PayloadEventDispatcher.kt` | `runtime/events` | Bridge OS |
| `TransportLayer.kt` | `runtime/transport` | Interface + impls |
| `RuntimeSessionManager.kt` | `runtime/session` | Orquestador |
| `PayloadManagerViewModel.kt` | `presentation/viewmodel` | VM dashboard |
| `PayloadTerminalViewModel.kt` | `presentation/viewmodel` | VM terminal |
| `PayloadEditorViewModel.kt` | `presentation/viewmodel` | VM editor |
| `PayloadManagerScreen.kt` | `presentation/ui/screens` | UI dashboard |
| `PayloadTerminalScreen.kt` | `presentation/ui/screens` | UI terminal |
| `PayloadEditorScreen.kt` | `presentation/ui/screens` | UI editor |
| `PayloadNavGraph.kt` | `presentation/ui` | Navigation |
| `PayloadModule.kt` | `di` | Hilt modules |
| `PayloadModule.kt` (root) | `payload` | Plugin entry point |
| `PayloadForegroundService.kt` | `service` | Android Service |

---

## ⚡ Flujo completo end-to-end

```
Usuario toca EXEC en PayloadManagerScreen
    ↓
PayloadManagerViewModel.executePayload(id)
    ↓
RuntimeSessionManager.enqueueExecution(id)
    → Crea PayloadSession en Room (state=QUEUED)
    → Lanza coroutine en serviceScope
    ↓
DuckyRuntimeEngine.execute(session, script)
    → DuckyScriptParser.parse(script) → List<DuckyAction>
    → TransportLayer.connect()
    → Por cada DuckyAction:
        → TransportLayer.sendKeyPress/sendString
        → Emite PayloadRuntimeEvent al SharedFlow
    ↓
RuntimeSessionManager (observa events)
    → Persiste log en Room vía appendSessionLog()
    → Actualiza state/progress/metrics en Room
    → PayloadEventDispatcher.dispatch(event)
        → CoreEventBus.emit()
        → RuntimeTelemetryManager.record()
        → OperationalTimeline.record()
    ↓
StateFlow → ViewModel → Compose recomposición mínima
    → PayloadTerminalScreen: logs en vivo + métricas HUD
    → PayloadManagerScreen: progress en ActiveSessionsBanner
```

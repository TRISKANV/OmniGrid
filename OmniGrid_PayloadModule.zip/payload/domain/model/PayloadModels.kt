package com.omnigrid.payload.domain.model

import java.util.UUID

// ─────────────────────────────────────────────
// Payload — modelo de dominio limpio
// ─────────────────────────────────────────────

data class Payload(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val script: String,
    val category: PayloadCategory = PayloadCategory.UNCATEGORIZED,
    val tags: List<String> = emptyList(),
    val isFavorite: Boolean = false,
    val workspaceId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val executionCount: Int = 0,
    val lastExecutedAt: Long? = null,
    val metadata: Map<String, String> = emptyMap()
)

// ─────────────────────────────────────────────
// PayloadCategory — taxonomía
// ─────────────────────────────────────────────

enum class PayloadCategory(val label: String, val colorHex: String) {
    UNCATEGORIZED("Uncategorized", "#555566"),
    RECON("Recon", "#00FFAA"),
    PERSISTENCE("Persistence", "#FF4455"),
    EXFILTRATION("Exfiltration", "#FFAA00"),
    LATERAL_MOVEMENT("Lateral Movement", "#AA00FF"),
    EVASION("Evasion", "#0088FF"),
    CUSTOM("Custom", "#FFFFFF")
}

// ─────────────────────────────────────────────
// PayloadSession — sesión de ejecución completa
// ─────────────────────────────────────────────

data class PayloadSession(
    val sessionId: String = UUID.randomUUID().toString(),
    val payloadId: String,
    val payloadName: String,
    val startedAt: Long = System.currentTimeMillis(),
    val endedAt: Long? = null,
    val state: ExecutionState = ExecutionState.QUEUED,
    val totalActions: Int = 0,
    val completedActions: Int = 0,
    val failedActions: Int = 0,
    val warnings: List<String> = emptyList(),
    val logs: List<SessionLog> = emptyList(),
    val transportState: TransportState = TransportState.DISCONNECTED,
    val executionMetrics: ExecutionMetrics = ExecutionMetrics()
) {
    val progress: Float
        get() = if (totalActions == 0) 0f else completedActions.toFloat() / totalActions.toFloat()

    val duration: Long
        get() = (endedAt ?: System.currentTimeMillis()) - startedAt

    val isTerminal: Boolean
        get() = state in listOf(
            ExecutionState.COMPLETED,
            ExecutionState.FAILED,
            ExecutionState.CANCELLED,
            ExecutionState.TIMEOUT
        )
}

// ─────────────────────────────────────────────
// ExecutionState — máquina de estados
// ─────────────────────────────────────────────

enum class ExecutionState {
    QUEUED,       // En cola, esperando
    INITIALIZING, // Preparando sesión y transport
    RUNNING,      // Ejecutando activamente
    PAUSED,       // Pausado manualmente
    COMPLETING,   // Último paso en curso
    COMPLETED,    // Terminado con éxito
    FAILED,       // Error crítico
    CANCELLED,    // Cancelado por el usuario
    TIMEOUT       // Timeout de transporte o ejecución
}

// ─────────────────────────────────────────────
// TransportState — estado del canal físico
// ─────────────────────────────────────────────

enum class TransportState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    TRANSMITTING,
    ERROR
}

// ─────────────────────────────────────────────
// SessionLog — entrada individual de log
// ─────────────────────────────────────────────

data class SessionLog(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val level: LogLevel,
    val tag: String,
    val message: String,
    val actionIndex: Int? = null
)

enum class LogLevel { DEBUG, INFO, WARN, ERROR, CRITICAL }

// ─────────────────────────────────────────────
// ExecutionMetrics — métricas de performance
// ─────────────────────────────────────────────

data class ExecutionMetrics(
    val queueWaitMs: Long = 0L,
    val initTimeMs: Long = 0L,
    val totalExecutionMs: Long = 0L,
    val avgActionLatencyMs: Long = 0L,
    val peakActionLatencyMs: Long = 0L,
    val retryCount: Int = 0,
    val bytesSent: Long = 0L
)

// ─────────────────────────────────────────────
// ExecutionResult — resultado puntual de action
// ─────────────────────────────────────────────

sealed class ExecutionResult {
    data class Success(
        val actionIndex: Int,
        val actionType: String,
        val latencyMs: Long
    ) : ExecutionResult()

    data class Failure(
        val actionIndex: Int,
        val actionType: String,
        val reason: String,
        val isRecoverable: Boolean = false
    ) : ExecutionResult()

    data class Warning(
        val actionIndex: Int,
        val message: String
    ) : ExecutionResult()
}

package com.omnigrid.payload.domain.usecase

import com.omnigrid.payload.domain.model.*
import com.omnigrid.payload.domain.repository.PayloadRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject

// ─────────────────────────────────────────────
// CreatePayloadUseCase
// ─────────────────────────────────────────────

class CreatePayloadUseCase @Inject constructor(
    private val repository: PayloadRepository
) {
    suspend operator fun invoke(
        name: String,
        script: String,
        description: String = "",
        category: PayloadCategory = PayloadCategory.UNCATEGORIZED,
        tags: List<String> = emptyList(),
        workspaceId: String? = null
    ): Payload {
        require(name.isNotBlank()) { "Payload name cannot be blank" }
        require(script.isNotBlank()) { "Payload script cannot be blank" }

        val payload = Payload(
            name = name.trim(),
            description = description.trim(),
            script = script,
            category = category,
            tags = tags.map { it.trim().lowercase() }.distinct(),
            workspaceId = workspaceId
        )
        repository.insertPayload(payload)
        return payload
    }
}

// ─────────────────────────────────────────────
// UpdatePayloadUseCase
// ─────────────────────────────────────────────

class UpdatePayloadUseCase @Inject constructor(
    private val repository: PayloadRepository
) {
    suspend operator fun invoke(payload: Payload) {
        require(payload.name.isNotBlank()) { "Payload name cannot be blank" }
        val updated = payload.copy(updatedAt = System.currentTimeMillis())
        repository.updatePayload(updated)
    }
}

// ─────────────────────────────────────────────
// DeletePayloadUseCase
// ─────────────────────────────────────────────

class DeletePayloadUseCase @Inject constructor(
    private val repository: PayloadRepository
) {
    suspend operator fun invoke(payloadId: String) {
        repository.deleteSessionsByPayload(payloadId)
        repository.deletePayload(payloadId)
    }
}

// ─────────────────────────────────────────────
// GetPayloadsUseCase — queries reactivas
// ─────────────────────────────────────────────

class GetPayloadsUseCase @Inject constructor(
    private val repository: PayloadRepository
) {
    fun all(): Flow<List<Payload>> = repository.observeAllPayloads()

    fun byCategory(category: PayloadCategory): Flow<List<Payload>> =
        repository.observePayloadsByCategory(category)

    fun favorites(): Flow<List<Payload>> = repository.observeFavorites()

    fun search(query: String): Flow<List<Payload>> =
        if (query.isBlank()) repository.observeAllPayloads()
        else repository.searchPayloads(query)

    fun byTag(tag: String): Flow<List<Payload>> =
        repository.observeAllPayloads().map { payloads ->
            payloads.filter { it.tags.contains(tag.lowercase()) }
        }
}

// ─────────────────────────────────────────────
// ExecutePayloadUseCase — dispara la ejecución
// ─────────────────────────────────────────────

class ExecutePayloadUseCase @Inject constructor(
    private val repository: PayloadRepository
) {
    suspend operator fun invoke(payloadId: String): PayloadSession {
        val payload = requireNotNull(repository.getPayloadById(payloadId)) {
            "Payload $payloadId not found"
        }

        val session = PayloadSession(
            payloadId = payloadId,
            payloadName = payload.name,
            state = ExecutionState.QUEUED
        )

        repository.insertSession(session)
        repository.incrementExecutionCount(payloadId)

        return session
    }
}

// ─────────────────────────────────────────────
// GetSessionLogsUseCase
// ─────────────────────────────────────────────

class GetSessionLogsUseCase @Inject constructor(
    private val repository: PayloadRepository
) {
    fun observe(sessionId: String): Flow<PayloadSession?> =
        repository.observeSessionById(sessionId)

    fun observeForPayload(payloadId: String): Flow<List<PayloadSession>> =
        repository.observeSessionsByPayload(payloadId)

    fun observeHistory(): Flow<List<PayloadSession>> =
        repository.observeExecutionHistory()
}

// ─────────────────────────────────────────────
// ManageSessionUseCase — control de sesión activa
// ─────────────────────────────────────────────

class ManageSessionUseCase @Inject constructor(
    private val repository: PayloadRepository
) {
    suspend fun cancel(sessionId: String) {
        repository.updateSessionState(
            sessionId = sessionId,
            state = ExecutionState.CANCELLED,
            endedAt = System.currentTimeMillis()
        )
    }

    suspend fun pause(sessionId: String) {
        repository.updateSessionState(sessionId, ExecutionState.PAUSED)
    }

    suspend fun resume(sessionId: String) {
        repository.updateSessionState(sessionId, ExecutionState.RUNNING)
    }

    fun observeActive(): Flow<List<PayloadSession>> =
        repository.observeActiveSessions()

    // Combina sesiones activas con totales para dashboard
    fun observeDashboardStats(): Flow<DashboardStats> =
        combine(
            repository.observeActiveSessions(),
            repository.observeExecutionHistory(limit = 100)
        ) { active, history ->
            DashboardStats(
                activeSessions = active.size,
                totalExecutions = history.size,
                successRate = history
                    .takeIf { it.isNotEmpty() }
                    ?.let { sessions ->
                        sessions.count { it.state == ExecutionState.COMPLETED }
                            .toFloat() / sessions.size.toFloat()
                    } ?: 0f,
                failureCount = history.count { it.state == ExecutionState.FAILED }
            )
        }
}

data class DashboardStats(
    val activeSessions: Int,
    val totalExecutions: Int,
    val successRate: Float,
    val failureCount: Int
)

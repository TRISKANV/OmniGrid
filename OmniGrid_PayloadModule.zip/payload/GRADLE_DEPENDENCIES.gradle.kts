// ══════════════════════════════════════════════════════════════════════════
// build.gradle (app) — dependencias para el módulo Payload Manager
// Agregar al bloque dependencies {} existente de OmniGrid
// ══════════════════════════════════════════════════════════════════════════

dependencies {

    // ── Room ──────────────────────────────────────────────────────────────
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")           // Flow support
    ksp("androidx.room:room-compiler:$roomVersion")

    // ── Hilt ─────────────────────────────────────────────────────────────
    val hiltVersion = "2.51.1"
    implementation("com.google.dagger:hilt-android:$hiltVersion")
    ksp("com.google.dagger:hilt-compiler:$hiltVersion")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")

    // ── Navigation Compose ────────────────────────────────────────────────
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // ── Lifecycle ─────────────────────────────────────────────────────────
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-service:2.8.2")    // ViewModel en Service

    // ── Coroutines ────────────────────────────────────────────────────────
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // ── Compose (si no están ya) ──────────────────────────────────────────
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.runtime:runtime")
    implementation("androidx.compose.animation:animation")
}

// ── plugins block (si no están ya) ────────────────────────────────────────
plugins {
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")
}

// ── KSP arguments para Room schema export ────────────────────────────────
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

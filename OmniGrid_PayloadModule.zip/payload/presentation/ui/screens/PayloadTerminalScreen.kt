package com.omnigrid.payload.presentation.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.omnigrid.payload.domain.model.*
import com.omnigrid.payload.presentation.viewmodel.*

// ─────────────────────────────────────────────
// PayloadTerminalScreen — HUD en vivo
// ─────────────────────────────────────────────

@Composable
fun PayloadTerminalScreen(
    sessionId: String,
    onBack: () -> Unit,
    viewModel: PayloadTerminalViewModel = hiltViewModel()
) {
    val session by viewModel.session.collectAsState()
    val liveEvents by viewModel.liveEvents.collectAsState()
    val metrics by viewModel.liveMetrics.collectAsState()
    val autoScroll by viewModel.autoScroll.collectAsState()

    val listState = rememberLazyListState()

    // Auto-scroll cuando llegan nuevos eventos
    LaunchedEffect(liveEvents.size) {
        if (autoScroll && liveEvents.isNotEmpty()) {
            listState.animateScrollToItem(liveEvents.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OmniColors.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            // ── Terminal Header ───────────────────────────────────────────────
            TerminalHeader(
                session = session,
                onBack = onBack,
                onCancel = { viewModel.cancelSession() }
            )

            // ── Metrics HUD ───────────────────────────────────────────────────
            SessionMetricsHUD(metrics = metrics)

            // ── Progress bar ──────────────────────────────────────────────────
            ExecutionProgressBar(
                progress = metrics.progress,
                state = metrics.state
            )

            HorizontalDivider(color = OmniColors.border, thickness = 1.dp)

            // ── Terminal log stream ───────────────────────────────────────────
            Box(modifier = Modifier.weight(1f)) {
                LiveTerminal(
                    events = liveEvents,
                    listState = listState,
                    onScrollChanged = { isAtBottom ->
                        viewModel.setAutoScroll(isAtBottom)
                    }
                )

                // Auto-scroll FAB
                if (!autoScroll) {
                    FloatingActionButton(
                        onClick = {
                            viewModel.setAutoScroll(true)
                        },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                            .size(36.dp),
                        containerColor = OmniColors.surfaceElevated,
                        contentColor = OmniColors.primary
                    ) {
                        Icon(
                            Icons.Default.KeyboardArrowDown,
                            contentDescription = "Auto scroll",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // ── Bottom toolbar ────────────────────────────────────────────────
            TerminalBottomBar(
                session = session,
                onClear = { viewModel.clearLiveEvents() },
                onCancel = { viewModel.cancelSession() }
            )
        }
    }
}

// ─────────────────────────────────────────────
// Terminal Header
// ─────────────────────────────────────────────

@Composable
private fun TerminalHeader(
    session: PayloadSession?,
    onBack: () -> Unit,
    onCancel: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(32.dp)) {
                Icon(
                    Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = OmniColors.textSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Text(
                    text = "RUNTIME TERMINAL",
                    color = OmniColors.primary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 2.sp
                )
                Text(
                    text = session?.sessionId?.take(12)?.uppercase() ?: "NO SESSION",
                    color = OmniColors.textSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }
        }

        session?.let {
            StateIndicator(state = it.state)
        }
    }

    HorizontalDivider(color = OmniColors.border)
}

// ─────────────────────────────────────────────
// Session Metrics HUD — 4 quadrant metrics
// ─────────────────────────────────────────────

@Composable
fun SessionMetricsHUD(metrics: LiveMetrics) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(OmniColors.surface)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        MetricCell(
            label = "ACTIONS",
            value = "${metrics.completedActions}/${metrics.totalActions}",
            valueColor = OmniColors.primary
        )
        MetricDivider()
        MetricCell(
            label = "FAILED",
            value = "${metrics.failedActions}",
            valueColor = if (metrics.failedActions > 0) OmniColors.error else OmniColors.textSecondary
        )
        MetricDivider()
        MetricCell(
            label = "DURATION",
            value = formatDuration(metrics.durationMs),
            valueColor = OmniColors.secondary
        )
        MetricDivider()
        MetricCell(
            label = "TRANSPORT",
            value = metrics.transportState.name.take(4),
            valueColor = metrics.transportState.toColor()
        )
        MetricDivider()
        MetricCell(
            label = "WARN",
            value = "${metrics.warningCount}",
            valueColor = if (metrics.warningCount > 0) OmniColors.warning else OmniColors.textSecondary
        )
    }
}

@Composable
private fun MetricCell(label: String, value: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            color = OmniColors.textSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            letterSpacing = 1.sp
        )
        Text(
            text = value,
            color = valueColor,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun MetricDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(28.dp)
            .background(OmniColors.border)
    )
}

// ─────────────────────────────────────────────
// Execution Progress Bar
// ─────────────────────────────────────────────

@Composable
fun ExecutionProgressBar(progress: Float, state: ExecutionState) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(300),
        label = "progress"
    )
    val progressColor = state.toColor()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(3.dp)
            .background(OmniColors.border)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(animatedProgress)
                .fillMaxHeight()
                .background(
                    Brush.horizontalGradient(
                        listOf(progressColor.copy(alpha = 0.6f), progressColor)
                    )
                )
        )
    }
}

// ─────────────────────────────────────────────
// Live Terminal — log stream
// ─────────────────────────────────────────────

@Composable
private fun LiveTerminal(
    events: List<LiveTerminalEntry>,
    listState: LazyListState,
    onScrollChanged: (Boolean) -> Unit
) {
    val isAtBottom by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
            val total = listState.layoutInfo.totalItemsCount
            lastVisible != null && lastVisible >= total - 2
        }
    }

    LaunchedEffect(isAtBottom) {
        onScrollChanged(isAtBottom)
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 4.dp),
        contentPadding = PaddingValues(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        items(
            items = events,
            key = { "${it.timestamp}_${it.message.hashCode()}" }
        ) { entry ->
            TerminalLogEntry(entry = entry)
        }
    }
}

@Composable
private fun TerminalLogEntry(entry: LiveTerminalEntry) {
    val levelColor = entry.level.toLogLevelColor()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (entry.isHighlight)
                    Modifier.background(levelColor.copy(alpha = 0.05f))
                else Modifier
            )
            .padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Timestamp
        Text(
            text = formatTimestamp(entry.timestamp),
            color = OmniColors.textSecondary.copy(alpha = 0.5f),
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            modifier = Modifier.width(52.dp)
        )

        // Level badge
        Text(
            text = entry.level,
            color = levelColor,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            modifier = Modifier.width(36.dp)
        )

        // Category accent
        Box(
            modifier = Modifier
                .width(2.dp)
                .height(14.dp)
                .background(entry.category.toColor().copy(alpha = 0.6f))
        )

        // Message
        Text(
            text = entry.message,
            color = if (entry.isHighlight) OmniColors.textPrimary else OmniColors.textPrimary.copy(alpha = 0.8f),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            modifier = Modifier.weight(1f)
        )
    }
}

// ─────────────────────────────────────────────
// State Indicator
// ─────────────────────────────────────────────

@Composable
private fun StateIndicator(state: ExecutionState) {
    val color = state.toColor()
    val isPulsing = state == ExecutionState.RUNNING

    val alpha by if (isPulsing) {
        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        infiniteTransition.animateFloat(
            initialValue = 0.4f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "alpha"
        )
    } else {
        remember { mutableFloatStateOf(1f) }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(3.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(50))
                .background(color.copy(alpha = alpha))
        )
        Text(
            text = state.name,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            letterSpacing = 1.sp
        )
    }
}

// ─────────────────────────────────────────────
// Bottom Bar
// ─────────────────────────────────────────────

@Composable
private fun TerminalBottomBar(
    session: PayloadSession?,
    onClear: () -> Unit,
    onCancel: () -> Unit
) {
    HorizontalDivider(color = OmniColors.border)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(OmniColors.surface)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Session ID
        Text(
            text = "SID:${session?.sessionId?.take(8) ?: "--------"}",
            color = OmniColors.textSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CompactActionButton(
                label = "CLEAR",
                color = OmniColors.textSecondary,
                onClick = onClear
            )

            val isActive = session?.isTerminal == false
            if (isActive) {
                CompactActionButton(
                    label = "ABORT",
                    color = OmniColors.error,
                    onClick = onCancel,
                    filled = true
                )
            }
        }
    }
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

private fun formatDuration(ms: Long): String {
    val seconds = ms / 1000
    val minutes = seconds / 60
    return if (minutes > 0) "${minutes}m${seconds % 60}s" else "${seconds}s"
}

private fun formatTimestamp(timestamp: Long): String {
    val s = (timestamp / 1000) % 86400
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return "%02d:%02d:%02d".format(h, m, sec)
}

private fun String.toLogLevelColor(): Color = when (this.trim()) {
    "CRIT" -> OmniColors.critical
    "ERR " -> OmniColors.error
    "WARN" -> OmniColors.warning
    "INFO", "OK  " -> OmniColors.primary
    else -> OmniColors.textSecondary
}

private fun TerminalCategory.toColor(): Color = when (this) {
    TerminalCategory.SESSION -> OmniColors.primary
    TerminalCategory.ACTION -> OmniColors.secondary
    TerminalCategory.TRANSPORT -> OmniColors.warning
    TerminalCategory.PARSE -> OmniColors.textSecondary
    TerminalCategory.WARNING -> OmniColors.warning
}

private fun TransportState.toColor(): Color = when (this) {
    TransportState.CONNECTED, TransportState.TRANSMITTING -> OmniColors.primary
    TransportState.CONNECTING -> OmniColors.warning
    TransportState.ERROR -> OmniColors.error
    TransportState.DISCONNECTED -> OmniColors.textSecondary
}

package com.omnigrid.payload.presentation.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.omnigrid.payload.presentation.ui.screens.PayloadEditorScreen
import com.omnigrid.payload.presentation.ui.screens.PayloadManagerScreen
import com.omnigrid.payload.presentation.ui.screens.PayloadTerminalScreen

// ─────────────────────────────────────────────
// PayloadNavGraph
// Rutas del módulo Payload Manager + Ducky Runtime
// ─────────────────────────────────────────────

sealed class PayloadRoute(val route: String) {
    object Manager : PayloadRoute("payload/manager")
    object Editor : PayloadRoute("payload/editor?payloadId={payloadId}") {
        fun build(payloadId: String? = null): String =
            if (payloadId != null) "payload/editor?payloadId=$payloadId"
            else "payload/editor"
    }
    object Terminal : PayloadRoute("payload/terminal/{sessionId}") {
        fun build(sessionId: String): String = "payload/terminal/$sessionId"
    }
}

@Composable
fun PayloadNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = PayloadRoute.Manager.route
    ) {
        composable(PayloadRoute.Manager.route) {
            PayloadManagerScreen(
                onNavigateToTerminal = { sessionId ->
                    navController.navigate(PayloadRoute.Terminal.build(sessionId))
                },
                onNavigateToEditor = { payloadId ->
                    navController.navigate(PayloadRoute.Editor.build(payloadId))
                }
            )
        }

        composable(
            route = PayloadRoute.Editor.route,
            arguments = listOf(
                navArgument("payloadId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) {
            PayloadEditorScreen(
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() }
            )
        }

        composable(
            route = PayloadRoute.Terminal.route,
            arguments = listOf(
                navArgument("sessionId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sessionId = backStackEntry.arguments?.getString("sessionId") ?: return@composable
            PayloadTerminalScreen(
                sessionId = sessionId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}

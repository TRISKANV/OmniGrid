package com.omnigrid.payload

import android.content.Context
import com.omnigrid.payload.domain.usecase.DashboardStats
import com.omnigrid.payload.runtime.session.RuntimeSessionManager
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

// ─────────────────────────────────────────────
// PayloadModule
// Punto de entrada del módulo al RuntimePluginSystem.
// Implementa la interface RuntimePlugin de OmniGrid.
//
// INTEGRACIÓN:
//   En RuntimePluginSystem.kt de OmniGrid:
//   pluginRegistry.register(payloadModule)
// ─────────────────────────────────────────────

@Singleton
class PayloadModule @Inject constructor(
    private val sessionManager: RuntimeSessionManager
) : OmniRuntimePlugin {

    override val moduleId: String = "payload.manager"
    override val moduleVersion: String = "1.0.0"
    override val moduleName: String = "Payload Manager + Ducky Runtime"

    override fun initialize(context: Context) {
        // El módulo es fully lazy — se inicializa vía DI en primer uso.
        // Aquí se puede registrar en OperationalTimeline, etc.
    }

    override fun shutdown() {
        // Cancela todas las sesiones activas si OmniGrid hace shutdown
        sessionManager // engine.cancelAll() vía sessionManager si se expone
    }

    override fun healthStatus(): PluginHealthStatus {
        return PluginHealthStatus.HEALTHY
    }
}

// ─────────────────────────────────────────────
// OmniRuntimePlugin interface
// Definida aquí temporalmente — mover al core de OmniGrid
// para que todos los módulos la implementen.
// ─────────────────────────────────────────────

interface OmniRuntimePlugin {
    val moduleId: String
    val moduleVersion: String
    val moduleName: String

    fun initialize(context: Context)
    fun shutdown()
    fun healthStatus(): PluginHealthStatus
}

enum class PluginHealthStatus { HEALTHY, DEGRADED, FAILED }

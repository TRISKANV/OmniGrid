package com.omnigrid.payload.runtime.transport

// ─────────────────────────────────────────────
// TransportLayer — abstracción del canal físico
// Implementaciones: USB HID, Bluetooth, Simulado
// ─────────────────────────────────────────────

interface TransportLayer {

    /**
     * Conecta al dispositivo. Retorna true si exitoso.
     */
    suspend fun connect(): Boolean

    /**
     * Desconecta limpiamente.
     */
    suspend fun disconnect()

    /**
     * Envía una pulsación de tecla con modificadores opcionales.
     * @param key nombre normalizado (ej: "A", "ENTER", "F1")
     * @param modifiers lista de modificadores (ej: ["CTRL", "SHIFT"])
     */
    suspend fun sendKeyPress(key: String, modifiers: List<String>)

    /**
     * Envía una cadena de texto carácter por carácter.
     */
    suspend fun sendString(text: String)

    /**
     * Retorna bytes enviados en la sesión actual.
     */
    fun bytesSent(): Long
}

// ─────────────────────────────────────────────
// SimulatedTransportLayer — para desarrollo y tests
// ─────────────────────────────────────────────

class SimulatedTransportLayer : TransportLayer {

    private var _bytesSent = 0L
    private var connected = false

    override suspend fun connect(): Boolean {
        kotlinx.coroutines.delay(50) // simula latencia de conexión
        connected = true
        return true
    }

    override suspend fun disconnect() {
        kotlinx.coroutines.delay(20)
        connected = false
    }

    override suspend fun sendKeyPress(key: String, modifiers: List<String>) {
        if (!connected) throw IllegalStateException("Transport not connected")
        kotlinx.coroutines.delay(10) // simula latencia de HID
        val encoded = "$key:${modifiers.joinToString("+")}"
        _bytesSent += encoded.length.toLong()
    }

    override suspend fun sendString(text: String) {
        if (!connected) throw IllegalStateException("Transport not connected")
        for (char in text) {
            kotlinx.coroutines.delay(5) // simula keystroke timing
        }
        _bytesSent += text.length.toLong()
    }

    override fun bytesSent(): Long = _bytesSent
}

// ─────────────────────────────────────────────
// UsbHidTransportLayer — stub para USB HID real
// ─────────────────────────────────────────────

class UsbHidTransportLayer : TransportLayer {

    private var _bytesSent = 0L

    override suspend fun connect(): Boolean {
        // TODO: Implementar UsbManager + UsbDeviceConnection
        // android.hardware.usb.UsbManager → openDevice → controlTransfer
        return false
    }

    override suspend fun disconnect() {
        // TODO: cerrar UsbDeviceConnection
    }

    override suspend fun sendKeyPress(key: String, modifiers: List<String>) {
        // TODO: HID report encoding según USB HID Usage Tables
        // Keycode → HID scancode + modifier byte → 8-byte report
        val report = buildHidReport(key, modifiers)
        sendHidReport(report)
        sendHidReport(ByteArray(8)) // key release
        _bytesSent += 16
    }

    override suspend fun sendString(text: String) {
        for (char in text) {
            sendKeyPress(char.toString(), emptyList())
            kotlinx.coroutines.delay(5)
        }
    }

    override fun bytesSent(): Long = _bytesSent

    private fun buildHidReport(key: String, modifiers: List<String>): ByteArray {
        // Modifier byte: bit0=LCTRL, bit1=LSHIFT, bit2=LALT, bit3=LGUI
        var modifierByte: Byte = 0
        for (mod in modifiers) {
            modifierByte = when (mod.uppercase()) {
                "CTRL", "CONTROL" -> (modifierByte.toInt() or 0x01).toByte()
                "SHIFT" -> (modifierByte.toInt() or 0x02).toByte()
                "ALT" -> (modifierByte.toInt() or 0x04).toByte()
                "GUI", "WINDOWS", "COMMAND" -> (modifierByte.toInt() or 0x08).toByte()
                else -> modifierByte
            }
        }
        val keycode = hidKeycode(key)
        return byteArrayOf(modifierByte, 0x00, keycode, 0x00, 0x00, 0x00, 0x00, 0x00)
    }

    private fun sendHidReport(report: ByteArray) {
        // TODO: UsbDeviceConnection.bulkTransfer(endpoint, report, 8, 100)
    }

    private fun hidKeycode(key: String): Byte = when (key.uppercase()) {
        "A" -> 0x04; "B" -> 0x05; "C" -> 0x06; "D" -> 0x07
        "E" -> 0x08; "F" -> 0x09; "G" -> 0x0A; "H" -> 0x0B
        "I" -> 0x0C; "J" -> 0x0D; "K" -> 0x0E; "L" -> 0x0F
        "M" -> 0x10; "N" -> 0x11; "O" -> 0x12; "P" -> 0x13
        "Q" -> 0x14; "R" -> 0x15; "S" -> 0x16; "T" -> 0x17
        "U" -> 0x18; "V" -> 0x19; "W" -> 0x1A; "X" -> 0x1B
        "Y" -> 0x1C; "Z" -> 0x1D
        "ENTER" -> 0x28; "ESCAPE", "ESC" -> 0x29; "BACKSPACE" -> 0x2A
        "TAB" -> 0x2B; "SPACE" -> 0x2C; "F1" -> 0x3A; "F2" -> 0x3B
        "F3" -> 0x3C; "F4" -> 0x3D; "F5" -> 0x3E; "F6" -> 0x3F
        "F7" -> 0x40; "F8" -> 0x41; "F9" -> 0x42; "F10" -> 0x43
        "F11" -> 0x44; "F12" -> 0x45
        "DELETE" -> 0x4C; "END" -> 0x4D; "HOME" -> 0x4A
        "UPARROW" -> 0x52; "DOWNARROW" -> 0x51
        "LEFTARROW" -> 0x50; "RIGHTARROW" -> 0x4F
        else -> 0x00
    }.toByte()
}

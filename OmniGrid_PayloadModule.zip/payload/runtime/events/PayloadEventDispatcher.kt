package com.omnigrid.payload.runtime.events

import com.omnigrid.payload.domain.model.ExecutionState
import javax.inject.Inject
import javax.inject.Singleton

// ─────────────────────────────────────────────
// PayloadEventDispatcher
// Puente entre el módulo Payload y el Runtime OS.
// Traduce PayloadRuntimeEvent → CoreEventBus events.
//
// INTEGRACIÓN: inyectar CoreEventBus, TelemetryManager
// y OperationalTimeline desde el Runtime OS aquí.
// ─────────────────────────────────────────────

@Singleton
class PayloadEventDispatcher @Inject constructor(
    // Inyectar desde Runtime OS — interfaces para no crear dependencias duras
    private val coreEventBus: OmniRuntimeEventBus,
    private val telemetry: OmniTelemetryBridge,
    private val timeline: OmniTimelineBridge
) {
    suspend fun dispatch(event: PayloadRuntimeEvent) {
        when (event) {

            // ── Lifecycle crítico → CoreEventBus ──────────────────────────────
            is PayloadRuntimeEvent.SessionStateChanged -> {
                coreEventBus.emit(
                    OmniRuntimeEvent.ModuleEvent(
                        module = "PayloadManager",
                        type = "SESSION_STATE",
                        payload = mapOf(
                            "sessionId" to event.sessionId,
                            "state" to event.state.name
                        )
                    )
                )

                // Timeline: registrar transiciones críticas
                if (event.state in listOf(
                        ExecutionState.RUNNING,
                        ExecutionState.COMPLETED,
                        ExecutionState.FAILED
                    )
                ) {
                    timeline.record(
                        moduleId = "payload.manager",
                        eventType = "execution.${event.state.name.lowercase()}",
                        label = "Payload Session → ${event.state.name}",
                        timestamp = System.currentTimeMillis()
                    )
                }
            }

            // ── Completado → telemetría completa ──────────────────────────────
            is PayloadRuntimeEvent.SessionCompleted -> {
                coreEventBus.emit(
                    OmniRuntimeEvent.ModuleEvent(
                        module = "PayloadManager",
                        type = "SESSION_COMPLETED",
                        payload = mapOf(
                            "sessionId" to event.sessionId,
                            "durationMs" to event.metrics.totalExecutionMs.toString(),
                            "completedActions" to event.completedActions.toString(),
                            "failedActions" to event.failedActions.toString()
                        )
                    )
                )

                telemetry.record(
                    metric = TelemetryMetric(
                        module = "payload.manager",
                        key = "session.duration_ms",
                        value = event.metrics.totalExecutionMs.toDouble(),
                        tags = mapOf("sessionId" to event.sessionId)
                    )
                )

                telemetry.record(
                    TelemetryMetric(
                        module = "payload.manager",
                        key = "session.success_rate",
                        value = if (event.failedActions == 0) 1.0 else
                            event.completedActions.toDouble() /
                                    (event.completedActions + event.failedActions).toDouble()
                    )
                )

                timeline.record(
                    moduleId = "payload.manager",
                    eventType = "execution.completed",
                    label = "Session completed (${event.completedActions} actions)",
                    timestamp = event.timestamp
                )
            }

            // ── Fallo → telemetría de error ───────────────────────────────────
            is PayloadRuntimeEvent.SessionFailed -> {
                coreEventBus.emit(
                    OmniRuntimeEvent.ModuleEvent(
                        module = "PayloadManager",
                        type = "SESSION_FAILED",
                        payload = mapOf(
                            "sessionId" to event.sessionId,
                            "reason" to event.reason
                        )
                    )
                )

                telemetry.record(
                    TelemetryMetric(
                        module = "payload.manager",
                        key = "session.failure",
                        value = 1.0,
                        tags = mapOf(
                            "sessionId" to event.sessionId,
                            "reason" to event.reason.take(100)
                        )
                    )
                )
            }

            // ── Warnings → telemetría ─────────────────────────────────────────
            is PayloadRuntimeEvent.Warning -> {
                telemetry.record(
                    TelemetryMetric(
                        module = "payload.manager",
                        key = "session.warning",
                        value = 1.0,
                        tags = mapOf("sessionId" to event.sessionId)
                    )
                )
            }

            else -> { /* Eventos de bajo nivel: no propagar al OS */ }
        }
    }
}

// ─────────────────────────────────────────────
// Interfaces del Runtime OS
// Implementadas por los componentes existentes de OmniGrid
// ─────────────────────────────────────────────

interface OmniRuntimeEventBus {
    suspend fun emit(event: OmniRuntimeEvent)
}

interface OmniTelemetryBridge {
    fun record(metric: TelemetryMetric)
}

interface OmniTimelineBridge {
    fun record(moduleId: String, eventType: String, label: String, timestamp: Long)
}

// ─────────────────────────────────────────────
// DTOs de integración
// ─────────────────────────────────────────────

sealed class OmniRuntimeEvent {
    data class ModuleEvent(
        val module: String,
        val type: String,
        val payload: Map<String, String> = emptyMap(),
        val timestamp: Long = System.currentTimeMillis()
    ) : OmniRuntimeEvent()
}

data class TelemetryMetric(
    val module: String,
    val key: String,
    val value: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val tags: Map<String, String> = emptyMap()
)

package com.omnigrid.payload.runtime.engine

import com.omnigrid.payload.domain.model.*
import com.omnigrid.payload.runtime.events.PayloadRuntimeEvent
import com.omnigrid.payload.runtime.transport.TransportLayer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

// ─────────────────────────────────────────────
// DuckyRuntimeEngine
// Pipeline: DuckyScript → Parser → Actions → Transport → Events
// ─────────────────────────────────────────────

@Singleton
class DuckyRuntimeEngine @Inject constructor(
    private val parser: DuckyScriptParser,
    private val transport: TransportLayer
) {
    // Event stream — todos los observadores subscriben aquí
    private val _events = MutableSharedFlow<PayloadRuntimeEvent>(
        replay = 0,
        extraBufferCapacity = 128
    )
    val events: SharedFlow<PayloadRuntimeEvent> = _events.asSharedFlow()

    // Scope supervisor — sobrevive fallos individuales
    private val engineScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default + CoroutineName("DuckyEngine")
    )

    // Jobs activos: sessionId → Job
    private val activeJobs = mutableMapOf<String, Job>()

    // ── API pública ───────────────────────────────────────────────────────────

    fun execute(session: PayloadSession, script: String): Job {
        val job = engineScope.launch {
            runCatching {
                runSession(session, script)
            }.onFailure { throwable ->
                if (throwable !is CancellationException) {
                    emit(
                        PayloadRuntimeEvent.SessionFailed(
                            sessionId = session.sessionId,
                            reason = throwable.message ?: "Unknown engine error",
                            timestamp = System.currentTimeMillis()
                        )
                    )
                }
            }
        }

        activeJobs[session.sessionId] = job

        job.invokeOnCompletion {
            activeJobs.remove(session.sessionId)
        }

        return job
    }

    fun cancel(sessionId: String) {
        activeJobs[sessionId]?.cancel(
            CancellationException("Session $sessionId cancelled by user")
        )
    }

    fun cancelAll() {
        activeJobs.values.forEach { it.cancel() }
        activeJobs.clear()
    }

    fun isRunning(sessionId: String): Boolean = activeJobs[sessionId]?.isActive == true

    // ── Internals ─────────────────────────────────────────────────────────────

    private suspend fun runSession(session: PayloadSession, script: String) {
        val sessionId = session.sessionId
        val startMs = System.currentTimeMillis()

        // 1. INITIALIZING
        emit(PayloadRuntimeEvent.SessionStateChanged(sessionId, ExecutionState.INITIALIZING))

        // 2. Parse
        val parseResult = parser.parse(script)

        if (parseResult.warnings.isNotEmpty()) {
            parseResult.warnings.forEach { warning ->
                emit(PayloadRuntimeEvent.Warning(sessionId, warning, System.currentTimeMillis()))
            }
        }

        emit(
            PayloadRuntimeEvent.ParseCompleted(
                sessionId = sessionId,
                actionCount = parseResult.actionCount,
                warnings = parseResult.warnings,
                timestamp = System.currentTimeMillis()
            )
        )

        // 3. Connect transport
        val transportConnected = transport.connect()
        emit(
            PayloadRuntimeEvent.TransportStateChanged(
                sessionId = sessionId,
                state = if (transportConnected) TransportState.CONNECTED else TransportState.ERROR,
                timestamp = System.currentTimeMillis()
            )
        )

        if (!transportConnected) {
            emit(
                PayloadRuntimeEvent.SessionFailed(
                    sessionId = sessionId,
                    reason = "Transport failed to connect",
                    timestamp = System.currentTimeMillis()
                )
            )
            return
        }

        // 4. RUNNING
        val initMs = System.currentTimeMillis() - startMs
        emit(PayloadRuntimeEvent.SessionStateChanged(sessionId, ExecutionState.RUNNING))

        var completed = 0
        var failed = 0
        val executionTimes = mutableListOf<Long>()

        // 5. Execute actions
        val executableActions = parseResult.actions.filter {
            it !is DuckyAction.Rem && it !is DuckyAction.DefaultDelay
        }

        for (action in executableActions) {
            ensureActive() // cancellation point

            val actionStart = System.currentTimeMillis()

            emit(
                PayloadRuntimeEvent.ActionStarted(
                    sessionId = sessionId,
                    actionIndex = action.index,
                    actionType = action::class.simpleName ?: "Unknown",
                    timestamp = actionStart
                )
            )

            val result = executeAction(action)
            val latency = System.currentTimeMillis() - actionStart
            executionTimes.add(latency)

            when (result) {
                is ExecutionResult.Success -> {
                    completed++
                    emit(
                        PayloadRuntimeEvent.ActionCompleted(
                            sessionId = sessionId,
                            actionIndex = action.index,
                            latencyMs = latency,
                            completed = completed,
                            total = executableActions.size,
                            timestamp = System.currentTimeMillis()
                        )
                    )
                }

                is ExecutionResult.Failure -> {
                    failed++
                    emit(
                        PayloadRuntimeEvent.ActionFailed(
                            sessionId = sessionId,
                            actionIndex = action.index,
                            reason = result.reason,
                            isRecoverable = result.isRecoverable,
                            timestamp = System.currentTimeMillis()
                        )
                    )

                    if (!result.isRecoverable) {
                        emit(
                            PayloadRuntimeEvent.SessionFailed(
                                sessionId = sessionId,
                                reason = "Non-recoverable action failure at index ${action.index}: ${result.reason}",
                                timestamp = System.currentTimeMillis()
                            )
                        )
                        transport.disconnect()
                        return
                    }
                }

                is ExecutionResult.Warning -> {
                    emit(
                        PayloadRuntimeEvent.Warning(
                            sessionId = sessionId,
                            message = result.message,
                            timestamp = System.currentTimeMillis()
                        )
                    )
                }
            }
        }

        // 6. Disconnect transport
        transport.disconnect()
        emit(
            PayloadRuntimeEvent.TransportStateChanged(
                sessionId = sessionId,
                state = TransportState.DISCONNECTED,
                timestamp = System.currentTimeMillis()
            )
        )

        // 7. Compute metrics
        val totalMs = System.currentTimeMillis() - startMs
        val metrics = ExecutionMetrics(
            initTimeMs = initMs,
            totalExecutionMs = totalMs,
            avgActionLatencyMs = if (executionTimes.isEmpty()) 0L else executionTimes.average().toLong(),
            peakActionLatencyMs = executionTimes.maxOrNull() ?: 0L,
            bytesSent = transport.bytesSent()
        )

        // 8. COMPLETED
        emit(
            PayloadRuntimeEvent.SessionCompleted(
                sessionId = sessionId,
                metrics = metrics,
                completedActions = completed,
                failedActions = failed,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    private suspend fun executeAction(action: DuckyAction): ExecutionResult {
        return when (action) {
            is DuckyAction.Delay -> {
                delay(action.millis)
                ExecutionResult.Success(action.index, "Delay", action.millis)
            }

            is DuckyAction.KeyPress -> {
                transport.sendKeyPress(action.key, action.modifiers)
                ExecutionResult.Success(action.index, "KeyPress", 0L)
            }

            is DuckyAction.StringType -> {
                transport.sendString(action.text)
                ExecutionResult.Success(action.index, "StringType", 0L)
            }

            is DuckyAction.StringTypeLine -> {
                transport.sendString(action.text)
                transport.sendKeyPress("ENTER", emptyList())
                ExecutionResult.Success(action.index, "StringTypeLine", 0L)
            }

            is DuckyAction.Led -> {
                ExecutionResult.Success(action.index, "Led", 0L)
            }

            is DuckyAction.Unknown -> {
                ExecutionResult.Warning(action.index, "Skipped unknown action: ${action.raw}")
            }

            else -> {
                ExecutionResult.Success(action.index, action::class.simpleName ?: "Action", 0L)
            }
        }
    }

    private suspend fun emit(event: PayloadRuntimeEvent) {
        _events.emit(event)
    }
}

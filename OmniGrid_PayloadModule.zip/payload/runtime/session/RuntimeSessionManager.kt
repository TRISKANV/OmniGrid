package com.omnigrid.payload.runtime.session

import com.omnigrid.payload.domain.model.*
import com.omnigrid.payload.domain.repository.PayloadRepository
import com.omnigrid.payload.runtime.engine.DuckyRuntimeEngine
import com.omnigrid.payload.runtime.events.PayloadRuntimeEvent
import com.omnigrid.payload.runtime.events.PayloadEventDispatcher
import com.omnigrid.payload.runtime.events.toLogLevel
import com.omnigrid.payload.runtime.events.toLogMessage
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// ─────────────────────────────────────────────
// RuntimeSessionManager
// Orquesta: Engine ↔ Repository ↔ OS EventBus
// Lifetime: Application scope (sobrevive Activity)
// ─────────────────────────────────────────────

@Singleton
class RuntimeSessionManager @Inject constructor(
    private val engine: DuckyRuntimeEngine,
    private val repository: PayloadRepository,
    private val eventDispatcher: PayloadEventDispatcher
) {
    private val managerScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineName("SessionManager")
    )

    // Cola de sesiones pendientes
    private val executionQueue = MutableStateFlow<List<String>>(emptyList())
    val queue: StateFlow<List<String>> = executionQueue.asStateFlow()

    init {
        // Escuchar todos los eventos del engine y persistirlos
        observeEngineEvents()
    }

    // ── API pública ───────────────────────────────────────────────────────────

    /**
     * Encola y ejecuta un payload. Retorna el sessionId.
     */
    suspend fun enqueueExecution(payloadId: String): String {
        // Crear sesión en DB
        val session = repository.getPayloadById(payloadId)?.let { payload ->
            PayloadSession(
                payloadId = payloadId,
                payloadName = payload.name,
                state = ExecutionState.QUEUED
            )
        } ?: throw IllegalArgumentException("Payload $payloadId not found")

        repository.insertSession(session)
        repository.incrementExecutionCount(payloadId)

        // Actualizar cola
        executionQueue.update { it + session.sessionId }

        // Lanzar ejecución
        managerScope.launch {
            executeSession(session)
        }

        return session.sessionId
    }

    fun cancel(sessionId: String) {
        engine.cancel(sessionId)
        managerScope.launch {
            repository.updateSessionState(
                sessionId = sessionId,
                state = ExecutionState.CANCELLED,
                endedAt = System.currentTimeMillis()
            )
        }
        executionQueue.update { it - sessionId }
    }

    fun pause(sessionId: String) {
        // En implementación real: señal al engine vía canal
        managerScope.launch {
            repository.updateSessionState(sessionId, ExecutionState.PAUSED)
        }
    }

    fun observeSession(sessionId: String): Flow<PayloadSession?> =
        repository.observeSessionById(sessionId)

    fun observeActiveSessions(): Flow<List<PayloadSession>> =
        repository.observeActiveSessions()

    // ── Internals ─────────────────────────────────────────────────────────────

    private suspend fun executeSession(session: PayloadSession) {
        val payload = repository.getPayloadById(session.payloadId) ?: run {
            repository.updateSessionState(
                sessionId = session.sessionId,
                state = ExecutionState.FAILED,
                endedAt = System.currentTimeMillis()
            )
            return
        }

        // Actualizar estado: INITIALIZING
        repository.updateSessionState(session.sessionId, ExecutionState.INITIALIZING)

        // Lanzar engine
        engine.execute(session, payload.script)

        // Remover de cola al completar
        executionQueue.update { it - session.sessionId }
    }

    private fun observeEngineEvents() {
        managerScope.launch {
            engine.events.collect { event ->
                processEvent(event)
            }
        }
    }

    private suspend fun processEvent(event: PayloadRuntimeEvent) {
        val sessionId = event.sessionId

        // 1. Persistir log en Room
        val log = SessionLog(
            timestamp = event.timestamp,
            level = event.toLogLevel(),
            tag = event::class.simpleName ?: "Event",
            message = event.toLogMessage(),
            actionIndex = when (event) {
                is PayloadRuntimeEvent.ActionStarted -> event.actionIndex
                is PayloadRuntimeEvent.ActionCompleted -> event.actionIndex
                is PayloadRuntimeEvent.ActionFailed -> event.actionIndex
                else -> null
            }
        )
        repository.appendSessionLog(sessionId, log)

        // 2. Actualizar estado de sesión según evento
        when (event) {
            is PayloadRuntimeEvent.SessionStateChanged -> {
                repository.updateSessionState(sessionId, event.state)
            }

            is PayloadRuntimeEvent.ActionCompleted -> {
                repository.updateSessionProgress(
                    sessionId = sessionId,
                    completedActions = event.completed,
                    failedActions = 0 // se actualiza acumulativo
                )
            }

            is PayloadRuntimeEvent.ActionFailed -> {
                val session = repository.getSessionById(sessionId)
                session?.let {
                    repository.updateSessionProgress(
                        sessionId = sessionId,
                        completedActions = it.completedActions,
                        failedActions = it.failedActions + 1
                    )
                }
            }

            is PayloadRuntimeEvent.TransportStateChanged -> {
                repository.updateTransportState(sessionId, event.state)
            }

            is PayloadRuntimeEvent.SessionCompleted -> {
                repository.updateSessionState(
                    sessionId = sessionId,
                    state = ExecutionState.COMPLETED,
                    endedAt = event.timestamp
                )
                repository.updateSessionMetrics(sessionId, event.metrics)
            }

            is PayloadRuntimeEvent.SessionFailed -> {
                repository.updateSessionState(
                    sessionId = sessionId,
                    state = ExecutionState.FAILED,
                    endedAt = event.timestamp
                )
            }

            else -> { /* Warning, ParseCompleted: solo log */ }
        }

        // 3. Forward al CoreEventBus del Runtime OS
        eventDispatcher.dispatch(event)
    }
}

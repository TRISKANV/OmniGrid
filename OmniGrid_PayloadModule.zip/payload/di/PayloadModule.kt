package com.omnigrid.payload.di

import android.content.Context
import androidx.room.Room
import com.omnigrid.payload.data.local.PayloadDatabase
import com.omnigrid.payload.data.local.dao.PayloadDao
import com.omnigrid.payload.data.local.dao.PayloadSessionDao
import com.omnigrid.payload.data.repository.PayloadRepositoryImpl
import com.omnigrid.payload.domain.repository.PayloadRepository
import com.omnigrid.payload.runtime.engine.DuckyRuntimeEngine
import com.omnigrid.payload.runtime.engine.DuckyScriptParser
import com.omnigrid.payload.runtime.events.OmniRuntimeEventBus
import com.omnigrid.payload.runtime.events.OmniTelemetryBridge
import com.omnigrid.payload.runtime.events.OmniTimelineBridge
import com.omnigrid.payload.runtime.events.PayloadEventDispatcher
import com.omnigrid.payload.runtime.transport.SimulatedTransportLayer
import com.omnigrid.payload.runtime.transport.TransportLayer
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// ─────────────────────────────────────────────
// PayloadDatabaseModule
// ─────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
object PayloadDatabaseModule {

    @Provides
    @Singleton
    fun providePayloadDatabase(@ApplicationContext context: Context): PayloadDatabase =
        Room.databaseBuilder(
            context,
            PayloadDatabase::class.java,
            PayloadDatabase.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun providePayloadDao(db: PayloadDatabase): PayloadDao = db.payloadDao()

    @Provides
    fun provideSessionDao(db: PayloadDatabase): PayloadSessionDao = db.sessionDao()
}

// ─────────────────────────────────────────────
// PayloadRepositoryModule
// ─────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
abstract class PayloadRepositoryModule {

    @Binds
    @Singleton
    abstract fun bindPayloadRepository(impl: PayloadRepositoryImpl): PayloadRepository
}

// ─────────────────────────────────────────────
// PayloadRuntimeModule
// ─────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
object PayloadRuntimeModule {

    @Provides
    @Singleton
    fun provideDuckyScriptParser(): DuckyScriptParser = DuckyScriptParser()

    @Provides
    @Singleton
    fun provideTransportLayer(): TransportLayer =
        // En producción: cambiar por UsbHidTransportLayer o BluetoothTransportLayer
        SimulatedTransportLayer()
}

// ─────────────────────────────────────────────
// OmniRuntimeBridgeModule
// Adapters que conectan las interfaces del Payload Module
// con los componentes reales del Runtime OS de OmniGrid.
//
// ⚠️ REEMPLAZAR estas implementaciones stub con las reales:
//   - OmniRuntimeEventBus → CoreEventBus de OmniGrid
//   - OmniTelemetryBridge → RuntimeTelemetryManager
//   - OmniTimelineBridge  → OperationalTimeline
// ─────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
object OmniRuntimeBridgeModule {

    @Provides
    @Singleton
    fun provideOmniRuntimeEventBus(): OmniRuntimeEventBus =
        object : OmniRuntimeEventBus {
            override suspend fun emit(event: com.omnigrid.payload.runtime.events.OmniRuntimeEvent) {
                // TODO: CoreEventBus.getInstance().emit(event.toCoreEvent())
                android.util.Log.d("OmniEventBus", "Event: $event")
            }
        }

    @Provides
    @Singleton
    fun provideOmniTelemetryBridge(): OmniTelemetryBridge =
        object : OmniTelemetryBridge {
            override fun record(metric: com.omnigrid.payload.runtime.events.TelemetryMetric) {
                // TODO: RuntimeTelemetryManager.record(metric)
                android.util.Log.d("OmniTelemetry", "${metric.key}=${metric.value}")
            }
        }

    @Provides
    @Singleton
    fun provideOmniTimelineBridge(): OmniTimelineBridge =
        object : OmniTimelineBridge {
            override fun record(moduleId: String, eventType: String, label: String, timestamp: Long) {
                // TODO: OperationalTimeline.record(moduleId, eventType, label, timestamp)
                android.util.Log.d("OmniTimeline", "[$moduleId] $eventType: $label")
            }
        }
}

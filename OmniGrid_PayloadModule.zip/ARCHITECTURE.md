# OmniGrid — Payload Manager + Ducky Runtime
## Arquitectura Completa del Módulo

---

## 📁 Estructura de Paquetes

```
com.omnigrid/
└── payload/
    ├── data/
    │   ├── local/
    │   │   ├── dao/
    │   │   │   ├── PayloadDao.kt
    │   │   │   └── PayloadSessionDao.kt
    │   │   ├── entity/
    │   │   │   ├── PayloadEntity.kt
    │   │   │   └── PayloadSessionEntity.kt
    │   │   └── PayloadDatabase.kt
    │   └── repository/
    │       └── PayloadRepositoryImpl.kt
    │
    ├── domain/
    │   ├── model/
    │   │   ├── Payload.kt
    │   │   ├── PayloadSession.kt
    │   │   ├── PayloadCategory.kt
    │   │   └── ExecutionResult.kt
    │   ├── repository/
    │   │   └── PayloadRepository.kt
    │   └── usecase/
    │       ├── CreatePayloadUseCase.kt
    │       ├── ExecutePayloadUseCase.kt
    │       ├── GetPayloadsUseCase.kt
    │       ├── GetSessionLogsUseCase.kt
    │       └── ManageSessionUseCase.kt
    │
    ├── runtime/
    │   ├── engine/
    │   │   ├── DuckyRuntimeEngine.kt
    │   │   ├── DuckyScriptParser.kt
    │   │   └── DuckyAction.kt
    │   ├── session/
    │   │   ├── RuntimeSessionManager.kt
    │   │   └── PayloadSessionState.kt
    │   ├── transport/
    │   │   ├── TransportLayer.kt
    │   │   └── TransportState.kt
    │   └── events/
    │       ├── PayloadRuntimeEvent.kt
    │       └── PayloadEventDispatcher.kt
    │
    ├── presentation/
    │   ├── viewmodel/
    │   │   ├── PayloadManagerViewModel.kt
    │   │   └── PayloadTerminalViewModel.kt
    │   └── ui/
    │       ├── screens/
    │       │   ├── PayloadManagerScreen.kt
    │       │   └── PayloadTerminalScreen.kt
    │       └── components/
    │           ├── PayloadCard.kt
    │           ├── ExecutionStatusBar.kt
    │           ├── RuntimeTerminal.kt
    │           └── SessionMetricsHUD.kt
    │
    └── service/
        └── PayloadForegroundService.kt
```

---

## 🧱 Capas y Responsabilidades

### DATA LAYER
- **PayloadDao / PayloadSessionDao**: Queries Room reactivos con Flow
- **PayloadEntity / PayloadSessionEntity**: Modelos de persistencia
- **PayloadRepositoryImpl**: Implementación concreta, mapeo entity↔domain

### DOMAIN LAYER
- **Payload**: Modelo de negocio limpio (sin Room annotations)
- **PayloadSession**: Estado completo de una sesión de ejecución
- **PayloadRepository**: Contrato puro de datos
- **UseCases**: Lógica de negocio atómica, un único propósito cada uno

### RUNTIME LAYER
- **DuckyScriptParser**: Tokeniza y parsea DuckyScript → lista de DuckyActions
- **DuckyRuntimeEngine**: Ejecuta actions, emite eventos, gestiona estado
- **RuntimeSessionManager**: Lifecycle de sesiones, persiste estado, coordina
- **TransportLayer**: Abstracción de transporte (USB HID, BT, simulado)
- **PayloadEventDispatcher**: Puente al CoreEventBus del Runtime OS

### PRESENTATION LAYER
- **PayloadManagerViewModel**: StateFlow de payloads, filtros, CRUD
- **PayloadTerminalViewModel**: Logs reactivos, métricas en vivo
- **PayloadManagerScreen**: Dashboard modular de payloads
- **PayloadTerminalScreen**: Terminal HUD en tiempo real

---

## 🔄 Runtime Flow

```
DuckyScript (texto)
    │
    ▼
DuckyScriptParser.parse()
    │  → List<DuckyAction>
    ▼
DuckyRuntimeEngine.execute(session, actions)
    │  → emite PayloadRuntimeEvent por cada step
    ▼
TransportLayer.dispatch(action)
    │  → abstrae el destino físico
    ▼
RuntimeSessionManager.onEvent(event)
    │  → actualiza PayloadSessionState
    │  → persiste en Room vía Repository
    ▼
PayloadEventDispatcher.emit(event)
    │  → CoreEventBus (Runtime OS)
    │  → RuntimeTelemetryManager
    │  → OperationalTimeline
    ▼
StateFlow → ViewModel → Compose UI
```

---

## 🔗 Integración con Runtime OS

| Componente OS       | Cómo se integra                                           |
|---------------------|-----------------------------------------------------------|
| CoreEventBus        | PayloadEventDispatcher emite PayloadRuntimeEvent          |
| RuntimeTelemetryManager | Recibe métricas: duración, warnings, failures         |
| RuntimeIntelligenceEngine | Analiza patrones de ejecución (futuro)             |
| OperationalTimeline | Cada sesión registra timestamps en el timeline            |
| RuntimePluginSystem | PayloadModule implementa RuntimePlugin interface          |

---

## ⚡ Foreground Resilience

- `PayloadForegroundService` corre el engine fuera del lifecycle de Activity
- `RuntimeSessionManager` sobrevive rotaciones vía `SavedStateHandle`
- Estado persistido en Room en cada evento crítico
- Coroutines en `Dispatchers.IO` + `SupervisorJob`
- UI reconstruye estado desde Room al resume

---

## 🎯 Performance

- `StateFlow` con `.distinctUntilChanged()` en cada pipe
- Compose keys estables en listas (`key = payload.id`)
- Logs en `LazyColumn` con `items(key = { it.id })`
- Room queries con `Flow<List<>>` (no suspend, reactivo puro)
- Engine en `Dispatchers.Default`, UI collect en `Dispatchers.Main.immediate`
